# Embedded-C
LTTS StepIn (Module 2- Activity)

# ACTIVITY_1
CIRCUIT
![iii](https://user-images.githubusercontent.com/67961861/126868071-cdda4184-f312-41d8-8636-6fcebf986907.PNG)
![Capture3_ACT-1](https://user-images.githubusercontent.com/67961861/126895818-33ff0568-3b47-41a2-aa52-c811e978caa7.PNG)
![Capture1_ACT-1](https://user-images.githubusercontent.com/67961861/126895862-e1db77fd-d104-4d55-818e-c95d81dee856.PNG)
![Capture2_ACT-1](https://user-images.githubusercontent.com/67961861/126895856-f4b8a859-d1df-4d6f-978a-5dbf43f037ff.PNG)





